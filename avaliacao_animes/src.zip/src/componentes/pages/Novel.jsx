import React from 'react';
import CustomCard from '../utils/Card.jsx';
import { Col, Row, Container } from 'react-bootstrap';
import { Routes, Route, useNavigate } from "react-router-dom";

function Novel(){
  return(
    <div className="Novel">
      <h1>Novel</h1>
    </div>
  )
}

export default Novel;